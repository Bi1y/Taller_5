class Persona < ApplicationRecord
end
